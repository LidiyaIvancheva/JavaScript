var array = [1, 2, 3, 4, 5, -3, 4, 0, 1, 3, 1, 1, 22, 16, 17, 1, 2];

var j = 0;
var count = 0;
var current = array[0];

  for (var i = 0; i < array.length -1; i++) {

            if (current < array[i]) {

                j = j + 1;

              //console.log('j = '+j);

            }
            if (j > 1 && count === 0) {
                count = count + 1;
                // console.log(i - j);
            };
                              
            if (j > 0 && current > array[i] ) {
                count = count + 1;

                //sconsole.log(i);
                j = 0;
            }           

            current = array[i];          
}

console.log(count);


