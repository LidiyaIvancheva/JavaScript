var arr = ['3.0', '6.0', '8.0', '21.0'], max, av;

var min = arr[0];
min = parseInt(min);

var sum = 0;

var count = 0;

for (var i = 0; i <= arr.length-1; i++) {

 	if (arr[i] < min) {
		arr[i] = min;
	}

	max = arr[arr.length-1];
	max = parseInt(max);
	if (arr[i] > max) {
		arr[i] = max;
	};


	n = parseInt(arr[i]);
	sum = sum + n;
	
	count =count + 1; 
	av = sum/count;
};

console.log("min = "+min.toFixed(2));
console.log("max = "+max.toFixed(2));
console.log("sum = "+sum.toFixed(2));
console.log("avg = "+av.toFixed(2));