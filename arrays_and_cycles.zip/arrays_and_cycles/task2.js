//var str = 'There is a man, his name was Bob. His favorite group is
//ABBA';
var str = 'There is a man his name was Bob His favorite group is ABBA';
str = str.toLowerCase();
//str = str.replace(/[^a-zA-Z0-9]+/g,'');
//str = str.replace(/[^\x20\x2D0-9A-Z\x5Fa-z\xC0-\xD6\xD8-\xF6\xF8-\xFF]/g);
//str = str.replace(/.,'/g,'');






//HELP!!!

//HOW TO REMOVE THE PONCTUATION MARKS???


string_to_array = function() {  
     return str.trim().split(" ");  
};  
//console.log(string_to_array(str));

var str1 = string_to_array(str);

for ( i = str1.length - 1; i >= 0; i--) {
	var rev = str1[i].split("").reverse().join("");  
		
		if (rev == str1[i]) {
			console.log(rev);
		}
}